<!-- footer -->
    <footer class="rafaa-section rp-footer rp-footer-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="wrap_footer_col">
                        <h3>About Us</h3>
                        <p>At Best Digi Solutions, everyone has a motto of “Digital Excellence and is aware of what it takes to be successful. </p>
                        
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="wrap_footer_col footer_col_links">
                        <h3 class="footer-head ">Useful Links</h3>
                        <ul class="footer_list">
                            <li><a href="about.php" title="about us">About Us</a></li>
                            <li><a href="services.php" title="about us">Service</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="wrap_footer_col footer_address">
                        <h3 class="footer-head ">Contact Us</h3>
                        <p><strong>Address - </strong>House Number - 43,<br>Village Kuttha, District Tehri Garhwal, Uttarakhand 249001</p>
                        <p><strong>Mail Us - </strong><a href="mailto:contact@bestdigisolutions.com" title="mailto">contact@bestdigisolutions.com</a></p>
                        <!-- <p><a href="#" title="+435-977-3779">435-977-3779</a></p>
                        <p><a href="#" title="+435-977-3779">435-977-3779</a></p> -->
                    </div>
                </div>
                
                <!-- <div class="col-lg-4 col-md-8 col-sm-12 col-12">
                    <div class="wrap_footer_col instagram_col">
                        <h3 class="footer-head ">Newsletter </h3>
                        <div class="subscripe_section">
                            <h5>Subscribe to our newsletter & get the insights and news</h5>
                            <form action="#" class="subscribe_form">
                                <p>
                                    <input type="text" name="email" placeholder="Your email address">
                                    <button type="submit" class="subcribe">Go!</button>
                                </p>
                            </form>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="row copywright_row">
                <div class="col-lg-7 col-md-7 col-12 ">
                    <p class="copywright">Copyright © 2018 All Rights Reserved
                        <a href="index.php">Best Digi Solutions</a>
                    </p>
                </div>
                <div class="col-5 col-md-5 col-12">
                    <ul class="privacy_list ">
                        <li><a href="privacy.php">Privacy Policy</a>|</li>
                        <li><a href="refund.php">Refund Policy</a>|</li>
                        <li><a href="terms.php">Terms &amp; Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- js library including -->
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/odometer.min.js"></script>
    <script src="js/chartjs.js"></script>
    <script src="js/noframework.waypoints.min.js"></script>
    <script src="js/index.js"></script>
    <script src="js/chartjs.js"></script>
    <script src="js/light-box.js"></script>
</body>

</html>