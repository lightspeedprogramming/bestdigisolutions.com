<!doctype html >
<html lang="en-US">


<!-- Mirrored from tagpointwp.com/raafa/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Sep 2018 09:01:50 GMT -->
<head>
    <meta charset="utf-8">
    <title> <?php echo $title; ?> </title>
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,500,600,700,800,900" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="css/all.min.css" media="all">
    <link rel="stylesheet" href="css/owl.carousel.min.css" media="all">
    <link rel="stylesheet" href="css/tp-animation.css" media="all">
    <link rel="stylesheet" href="css/style.css" media="all">
    <link rel="stylesheet" href="css/responsive.css" media="all">
</head>

<body>
    <!-- perload section -->
    <!-- <div id="preloader">
        <div id="preloader-inner"></div>
    </div> -->
    <!-- header section -->
    <header class="tp-main-menu header-menu-1 sticky-header">
        <div class="fixed-top" style="text-align:center;background:#f6364d;width:100%; position:fixed;max-height: 26px;">
          <div class="container">
            <p style="text-align:center; font-size:18px!important"><a style="color:#fff" href="mailto: contact@bestdigisolutions.com"><i class="fa fa-envelope" style="color:white;"></i> contact@bestdigisolutions.com</a></p>
          </div>
        </div>
        <!-- top logo/contac inf -->
        <div class="container">
            <div class="row row_menu_2">
                <div class="col-lg-3 col-md-12 col-12 col-logo-3">
                    <div class="my-tagpoint-wrap-logo">
                        <a href="index.php" title="Best Digi Solutions ">
                            <!-- <img src="images/light_logo.png" alt="Rafaa Template" class="tp_whitelogo"> -->
                            Best Digi Solutions 
                        </a>
                        <span class="phone_menu  primary-color">
                            <i class="fas fa-bars"></i>
                        </span>
                    </div>
                </div>
                <div class="col-lg-9 col-md-12 col-12">
                    <nav class="tp-menu tagpoint-menu-2">
                        <ul class="tagpoint-main-menu" style="padding-top: 19px;">
                            <li class="current_page_item  has-sub ">
                                
                                <a title="Home" href="index.php">
                                            
                                            Home
                                        </a>
                            </li>
                            <li class="has-sub">
                                
                                <a title="About Us" href="about.php">
                                            
                                            About Us
                                        </a>
                            </li>
                            <li class="has-sub">
                                
                                <a title="Services" href="services.php">
                                            
                                            Services
                                        </a>
                            </li>
                            <li>
                                
                                <a title="Services" href="contact.php">
                                            Contact Us
                                        </a>
                            </li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>